extern int return_code;

void set_return_code (int code)
{
	return_code	=	code;
}
