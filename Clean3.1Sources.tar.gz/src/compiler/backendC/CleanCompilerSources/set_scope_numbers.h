
void set_scope_numbers (RuleAltS *rule_alt_p);


