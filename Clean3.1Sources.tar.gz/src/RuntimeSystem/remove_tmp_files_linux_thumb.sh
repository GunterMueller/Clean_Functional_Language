rm tstartup.o tfileIO3.o scon.o ufileIO2.o tdivmod.o tdiv.o tludiv.o

