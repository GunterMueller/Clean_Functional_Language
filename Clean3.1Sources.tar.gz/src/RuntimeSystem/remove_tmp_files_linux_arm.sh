rm armstartup.o armfileIO3.o scon.o ufileIO2.o armdivmod.o armudiv.o armludiv.o

