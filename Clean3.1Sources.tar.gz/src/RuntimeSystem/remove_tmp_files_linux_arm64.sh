rm arm64startup.o arm64fileIO3.o scon.s scon.o ufileIO2.o
