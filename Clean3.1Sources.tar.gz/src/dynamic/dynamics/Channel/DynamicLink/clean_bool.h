#ifndef CLEANBOOLH
#define CLEANBOOLH

typedef int CLEAN_BOOL;
#define CLEAN_FALSE	0
#define CLEAN_TRUE	1

#endif