
#define ALLOC_GLOBALH
#include "global.h"
