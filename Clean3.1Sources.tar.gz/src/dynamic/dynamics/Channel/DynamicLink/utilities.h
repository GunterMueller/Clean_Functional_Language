#ifndef UTILITIESH
#define UTILITIESH


/*
** Includes
*/
#include <windows.h>

/*
** DEFINEs
*/


/*
** External functions
*/
void error();
void msg(char *lpMsgBuf);

/*
** API Functions
*/

#endif 