char *SelectDynamicLinkerFolder();

