
extern int return_code;

void set_return_code (int v)
{
	return_code=v;
}