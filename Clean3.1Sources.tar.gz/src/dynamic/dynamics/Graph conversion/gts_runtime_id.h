
#define RTID_TYPE_STRING			0
#define RTID_RUNTIME_ID				4		// must have been ored with LAZY_DYNAMIC_INSTANCE
#define RTID_ASSIGNED_DISK_ID		8		// id on disk

#define LAZY_LIBRARY_INSTANCE	0x80000000
