// This file is an interface between the graph_to_string-conversion function and the
// dynamic run-time system which has to process the results.
//
// update StdDynamicLowLevelInterface

#define CODE_LIBRARY_INSTANCE	0x80000000
#define TYPE_LIBRARY_INSTANCE	0x40000000

#define LIBRARY_INSTANCE_MASK	0x3fffffff
