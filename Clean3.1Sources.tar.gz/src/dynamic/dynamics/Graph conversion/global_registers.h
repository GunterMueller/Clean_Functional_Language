
#define nodeP	%eax
#define descP	%ebx
#define arity	%ecx
#define heapP	%edi
#define stackP	%edx
#define free 	%ebp
#define source	%esi
#define stringP	source

// General constants 
#define MACHINE_WORD_BSIZE	4	// in bytes
