# clean-ide

This contains the Windows IDE, batchbuild and cpm.

## Automatic builds

cpm is included in all clean distributions. However, if you cannot wait for the
nightly build you can download one of the automatic builds here:

- [linux-64](https://gitlab.science.ru.nl/clean-and-itasks/clean-ide/builds/artifacts/master/file/cpm/cpm?job=test)
