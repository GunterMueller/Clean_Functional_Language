clm -IL ArgEnv -IL StdLib -IL StdEnv -IL Directory -I ../Pm -I ../Util -I ../Unix -I ../Unix/Intel -I ../Interfaces/LinkerInterface BatchBuild -o batch_build
