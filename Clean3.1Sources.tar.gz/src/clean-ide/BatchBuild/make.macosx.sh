clm -IL ArgEnv -IL StdLib -IL StdEnv -IL Directory -I ../Pm -I ../Util -I ../MacOSX -I ../Unix -I ../Interfaces/LinkerInterface BatchBuild -o batch_build
