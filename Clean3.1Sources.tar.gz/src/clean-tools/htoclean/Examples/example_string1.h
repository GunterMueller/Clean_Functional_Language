
void spaces_string (int n_spaces,CleanString*);
Clean (spaces_string :: Int -> String)

void hello_string_from_c (CleanString *);
Clean (hello_string_from_c :: -> String)

int string_to_uppercase_with_side_effect (CleanString);
Clean (string_to_uppercase_with_side_effect :: String -> Int)
