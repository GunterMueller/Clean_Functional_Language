
int sum_int_array (CleanIntArray a);
Clean (sum_int_array :: {#Int} -> Int)

double sum_real_array (CleanRealArray a);
Clean (sum_real_array :: {#Real} -> Real)

int first_different_char_index (CleanCharArray a1,CleanCharArray a2);
Clean (f :: {#Char} {#Char} -> Int)
