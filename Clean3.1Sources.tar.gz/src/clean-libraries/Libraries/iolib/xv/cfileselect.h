extern char *duplicate_string(char *);
extern char *append_strings3(char *, char *, char *);
extern void init_file_selector(void);
