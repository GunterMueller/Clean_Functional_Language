extern MyBoolean TimerEnabled;
extern void allow_timer(int);
extern void init_timer(void);
