#include <X11/Xlib.h>
#include "windowdata.h"

extern GC make_new_gc(void);
extern void init_picture(void);
extern void set_default_font(WindowData *);
extern void FreePictureData(WindowData *);
