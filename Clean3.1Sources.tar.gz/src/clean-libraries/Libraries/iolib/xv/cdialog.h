extern void init_dialog(void);
