
CleanString get_home_path(int);
CleanString get_appl_path(int);
