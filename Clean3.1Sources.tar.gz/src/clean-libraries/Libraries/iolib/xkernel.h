
int init_toplevelx(int);
int set_toplevelname(CleanString);
int close_toplevelx(int);
int open_toplevelx(int);
int show_toplevelx(int);
int hide_toplevelx(int);
Clean(single_event_catch :: Int -> (Int,Int))
void single_event_catch(int,int *,int *);
int destroy_widget(int);
