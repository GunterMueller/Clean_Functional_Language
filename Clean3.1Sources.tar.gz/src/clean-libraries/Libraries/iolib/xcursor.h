
int set_window_cursor(int,int);
