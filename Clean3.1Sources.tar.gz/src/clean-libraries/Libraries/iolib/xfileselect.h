Clean(select_input_file :: Int -> (Int,String))
void select_input_file(int, int *,CleanString *);
Clean(select_output_file :: String String -> (Int,String));
void select_output_file(CleanString,CleanString,int *,CleanString *);
