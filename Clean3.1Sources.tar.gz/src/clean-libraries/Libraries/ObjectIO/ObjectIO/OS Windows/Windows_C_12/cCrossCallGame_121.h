#include <windows.h>
#include "cGameLib_121.h"
#include "cCrossCall_121.h"

/*	Install the cross call procedures in the gCrossCallProcedureTable of cCrossCall_121.
*/
extern int InstallCrossCallGame (int ios);
