#include <windows.h>
#include "util_121.h"

//	InstallCrossCallFileSelectors adds the proper cross call procedures to the
//	cross call procedures managed by cCrossCall_121.c.
extern int InstallCrossCallWindows (int ios);
