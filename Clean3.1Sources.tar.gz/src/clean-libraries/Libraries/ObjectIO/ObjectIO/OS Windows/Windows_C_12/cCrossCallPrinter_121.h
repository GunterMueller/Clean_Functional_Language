#include <windows.h>


/*	Install the cross call procedures in the gCrossCallProcedureTable of cCrossCall_121.
*/
extern int InstallCrossCallPrinter (int ios);
