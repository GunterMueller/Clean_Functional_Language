#include "util_121.h"

/*	Install the cross call procedures in the gCrossCallProcedureTable of cCrossCall_121.
*/
extern OS InstallCrossCallMenus (OS);
