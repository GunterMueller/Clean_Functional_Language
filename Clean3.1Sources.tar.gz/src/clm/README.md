# clm - Clean make - version 3.0

### Automatic builds

clm is included in all clean distributions. However, if you cannot wait for the
nightly build you can download one of the automatic builds here:

- [linux-64](https://gitlab.science.ru.nl/clean-and-itasks/clm/builds/artifacts/master/file/clm?job=linux)

### Contributing

The source code for clm must be ANSI C compliant
