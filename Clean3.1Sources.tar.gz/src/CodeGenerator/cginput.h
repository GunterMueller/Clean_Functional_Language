void initialize_parser (VOID);
int parse_file (FILE *file);
