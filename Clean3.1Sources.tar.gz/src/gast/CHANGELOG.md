# Changelog

## 21.7

No changes

## 21.6

### Fixes
- `quietn`/`quiet` now print CE including arguments; `verbosePrintConfig` includes printing CE args, Gijs Alberts (@gijstop), !54

## 21.5

No changes

## 21.4

### Fixes
- fix with_options.icl which was broken by recent change in Data.Set API, Steffen Michels (@smichels), !49

## 21.3

No changes

## 21.2

- Added license

## 21.1

First tagged release
