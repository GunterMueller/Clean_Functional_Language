This repository contains the G∀ST testing framework for Clean.

An overview of the library and the underlying ideas is provided in:

* ftp://ftp.cs.ru.nl/pub/CSI/SoftwEng.FunctLang/papers/2006/koop2006-AutomaticTestingFunctionSpecificationsCEFPS.pdf
* https://www.researchgate.net/publication/235900230_Model_Based_Testing_with_Logical_Properties_versus_State_Machines
